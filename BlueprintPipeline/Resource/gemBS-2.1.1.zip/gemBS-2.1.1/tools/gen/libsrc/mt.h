struct {
    unsigned int aaa;
    unsigned int maskB, maskC;
} mts;

