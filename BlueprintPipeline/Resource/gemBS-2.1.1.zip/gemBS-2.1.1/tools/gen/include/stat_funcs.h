double cumchic(double,int);
double cumchn(double,int,double);
double critchn(double,int,double);
double critchi(double,int);
double lbetaix(double,double,double,double);
double betaix(double,double,double,double);
double lbetai(double,double,double);
double betai(double,double,double);
double betacf(double a, double b, double x);
