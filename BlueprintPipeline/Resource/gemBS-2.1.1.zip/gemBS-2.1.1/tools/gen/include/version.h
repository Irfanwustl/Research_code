#ifndef _VERSION_H_
#define _VERSION_H_

#define VERSION "2.4.8"
#define LOKI_NAME "loki " VERSION
#define PREP_NAME "prep " VERSION
#define HET_VERSION "0.1"
#define HET_NAME "check_het " HET_VERSION
#define FENRIS_VERSION "0.1"
#define FENRIS_NAME "fenris " FENRIS_VERSION

#endif
