/*
 *  link_list.h
 *  loki
 *
 *  Created by Simon Heath on 19/04/2007.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

struct link_list {
	struct list;
	void *data;
};
